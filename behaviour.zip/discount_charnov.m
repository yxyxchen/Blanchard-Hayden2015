function discount_charnov(tt,lt)

for repeat=1:10,
    for tt=1:10,
        e(repeat,tt)=c2oe(tt);
        
    end
    cntr(repeat)
end
keyboard

